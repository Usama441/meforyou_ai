class Message < ApplicationRecord
  belongs_to :conversation
end
