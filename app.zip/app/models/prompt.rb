class Prompt < ApplicationRecord
  belongs_to :user
end
