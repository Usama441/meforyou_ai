module ChatHelper
  RELATIONSHIP_OPTIONS = [
    ['Friend', 'friend'],
    ['Mother', 'mother'],
    ['Father', 'father'],
    ['Partner', 'partner'],
    ['Sibling', 'sibling'],
    ['Spouse', 'spouse'],
    ['Child', 'child'],
    ['Colleague', 'colleague'],
    ['Custom', 'custom']
  ]
end