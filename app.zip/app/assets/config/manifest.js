//= link application.css
//= link_directory ../stylesheets .css
//= link application.js

//= link_tree ../../javascript .js
//= link_tree ../../../vendor/javascript .js
//= link chat_stream.js
//= link logo.png

//= link_directory ../images/favicons .png
//= link favicons/favicon.ico
//= link favicons/site.webmanifest